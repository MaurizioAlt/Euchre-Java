/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import constants.Constants;
import constants.Constants.Suit;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author mauri
 */
public class Game
{

    private Suit TRUMPSUIT; 
    private Player lead;
    private Player dealer;
    private Player winner;
    private int round;
    private ArrayList<Team> teams;
    private Deck deck;
    Scanner scan = new Scanner(System.in);

    public Suit getTRUMPSUIT() {
        return TRUMPSUIT;
    }

    public void setTRUMPSUIT(Suit TRUMPSUIT) {
        this.TRUMPSUIT = TRUMPSUIT;
    }

    public Player getLead() {
        return lead;
    }

    public void setLead(Player lead) {
        this.lead = lead;
    }

    public Player getDealer() {
        return dealer;
    }

    public void setDealer(Player dealer) {
        this.dealer = dealer;
    }

    public Player getWinner() {
        return winner;
    }

    public void setWinner(Player winner) {
        this.winner = winner;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public ArrayList<Team> getTeams() {
        return teams;
    }

    public void setTeams(ArrayList<Team> teams) {
        this.teams = teams;
    }

    public Deck getDeck() {
        return deck;
    }

    public void setDeck(Deck deck) {
        this.deck = deck;
    }

    public Scanner getScan() {
        return scan;
    }

    public void setScan(Scanner scan) {
        this.scan = scan;
    }

    public Game()
    {
        createTeams();
        outputTeams();
        //createDeck();
    }
    
    
    private void createTeams()
    {
        teams = new ArrayList();
        
        Team teamOne = new Team();
        teamOne.setTeamName("Team One");
        teams.add(teamOne);
        
        Team teamTwo = new Team();
        teamTwo.setTeamName("Team Two");
        teams.add(teamTwo);
        
        scan = new Scanner(System.in);
        System.out.println("Enter human player name");
        String name = scan.next();

        HumanPlayer hp = new HumanPlayer();
        hp.setName(name);
        System.out.println("Human Player added to Team One!");
        teamOne.getPlayers().add(hp);
        
        for(int p = 1; p <= Constants.NUM_AI_PLAYERS; p++)
        {
            AiPlayer aip = new AiPlayer();
            aip.setName("AI " + p);
            
            if(teamOne.getPlayers().size() < 2)
                teamOne.getPlayers().add(aip);
            else
                teamTwo.getPlayers().add(aip);
        }
    }
    
    private void outputTeams()
    {
        for(Team team: teams)
            team.outputTeams();
    }
    
    //private void createDeck()
}
