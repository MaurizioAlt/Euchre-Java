/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author mauri
 */
public abstract class Player implements IPlayer 
{
    private String name; 
    
    @Override
    public abstract Card playCard();
    
    @Override
    public abstract void makeTrump();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
