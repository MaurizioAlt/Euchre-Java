/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import constants.Constants;
import core.Game;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author mauri
 */
public class GameUi
{
    
    private Game game;
    private JFrame frame;
    private JPanel aiOnePanel;
    private JPanel tablePanel;
    private JPanel aiTwoPanel;
    private JPanel hpPanel;
    private JPanel aiThreePanel;
    private JPanel northPanel;
    private JPanel scorePanel;
    private JMenuBar menuBar;
    private JMenu gameMenu;
    private JMenu helpMenu;
    private JMenuItem newGameMenuItem;
    private JMenuItem exitMenuItem;
    private JMenuItem aboutMenuItem;
    private JMenuItem rulesMenuItem;
    
    /**
     *
     * @param game
     */
    public GameUi(Game game)
    {
        this.game = game;
        initComponents();
        frame.setVisible(true);
    }

    private void initComponents()
    {
        initMenuBar();
        layoutTable();
    }

    private void initMenuBar()
    {
        frame = new JFrame("Euchre");
        gameMenu = new JMenu("Menu");
        menuBar = new JMenuBar();        
        frame.setJMenuBar(menuBar);
        
        newGameMenuItem = new JMenuItem("New Game");
        newGameMenuItem.addActionListener(new NewGameListener());
        exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(new ExitListener());
        
        helpMenu = new JMenu("Help");
        aboutMenuItem = new JMenuItem("About");
        aboutMenuItem.addActionListener(new AboutListener());
        rulesMenuItem = new JMenuItem("Game Rules");
        rulesMenuItem.addActionListener(new RulesListener());
        
        gameMenu.add(newGameMenuItem);
        gameMenu.add(exitMenuItem);
        
        helpMenu.add(aboutMenuItem);
        helpMenu.add(rulesMenuItem);
        
        menuBar.add(gameMenu);
        menuBar.add(helpMenu);
    }

    private void layoutTable()
    {
        //frame = new JFrame("Euchre");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 1000);
        
        aiOnePanel = new AiPlayerUi(game.getTable().get(Constants.POSITION_2), Constants.POSITION_2);
        aiTwoPanel = new AiPlayerUi(game.getTable().get(Constants.POSITION_3), Constants.POSITION_3);
        aiThreePanel = new AiPlayerUi(game.getTable().get(Constants.POSITION_4), Constants.POSITION_4);
        hpPanel = new HumanPlayerUi(game.getTable().get(Constants.POSITION_1));
        
        initNorthPanel();
        initTablePanel();
        
        frame.add(aiOnePanel, BorderLayout.WEST);
        frame.add(northPanel, BorderLayout.NORTH);
        frame.add(aiThreePanel, BorderLayout.EAST);
        frame.add(hpPanel, BorderLayout.SOUTH);
        frame.add(tablePanel, BorderLayout.CENTER);
        
    }
    
    private void initNorthPanel()
    {
        northPanel = new JPanel();
        northPanel.setMinimumSize(new Dimension(980, 150));
        northPanel.setPreferredSize(new Dimension(980, 150));
        
        scorePanel = new JPanel();
        scorePanel.setBorder(BorderFactory.createTitledBorder("Score"));
        scorePanel.setMinimumSize(new Dimension(90, 140));
        scorePanel.setPreferredSize(new Dimension(90, 140));
        
        aiTwoPanel.setMinimumSize(new Dimension(700, 140));
        aiTwoPanel.setPreferredSize(new Dimension(700, 140));
        
        northPanel.add(scorePanel);
        northPanel.add(aiTwoPanel);
    }
    
    private void initTablePanel()
    {
        tablePanel = new JPanel();
        tablePanel.setBorder(BorderFactory.createTitledBorder("Euchre"));
        tablePanel.setMaximumSize(new Dimension(200, 200));
        tablePanel.setMinimumSize(new Dimension(200, 200));
        tablePanel.setPreferredSize(new Dimension(200, 200));
    }
    
    private class NewGameListener implements ActionListener
    {
        
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            
        }
    }
    
    private class ExitListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            int response = JOptionPane.showConfirmDialog(frame, "Confirm to exit Euchre?",
                    "Exit?", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
                System.exit(0);
        }
    }
    
    private class AboutListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            String message = "Euchre version 1.0\nMaurizio Altamura\nSummer 2018";
            JOptionPane.showMessageDialog(frame, message);
        }
    }
    
    private class RulesListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            
        }
    }
}
