/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import constants.Constants;
import constants.Constants.Color;
import constants.Constants.Face;
import static constants.Constants.Face.ACE;
import static constants.Constants.Face.NINE;
import constants.Constants.Suit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mauri
 */
public class Deck 
{
    private Set<Card> deck;

    public Deck()
    {
        System.out.println("***********************************");
        System.out.println("Generating the deck of cards");
        System.out.println("***********************************");
        generateDeck();
        System.out.println("***********************************");
        System.out.println("Displaying the deck of cards");
        System.out.println("***********************************");
        displayDeck();
        System.out.println("***********************************");
        System.out.println("Shuffling the deck of cards");
        System.out.println("***********************************");
        shuffleDeck();
        System.out.println("***********************************");
        System.out.println("Displaying the deck of cards");
        System.out.println("***********************************");
        displayDeck();
    }
    
    public Set<Card> getDeck() {
        return deck;
    }

    public void setDeck(Set<Card> deck) {
        this.deck = deck;
    }
    
    //Set set = new HashSet<Set>();
    
    private void generateDeck()
    {
        deck = new HashSet<>(Constants.NUM_CARDS);
        
        for(Face face : Face.values())
        {
            for(Suit suit : Suit.values())
            {
                Card newcard = new Card();
                newcard.setFace(face);
                newcard.setSuit(suit);
                if(suit == Suit.DIAMONDS || suit == Suit.HEARTS)
                    newcard.setColor(Color.RED);
                else
                    newcard.setColor(Color.Black);
                //check for duplicates
                boolean success;
                if(!deck.contains(newcard))
                    success = deck.add(newcard);
                //set.add(new Set(it, ti, face));
            }
        }
    }

    private void displayDeck()
    {
        System.out.println("Deck size: " + deck.size() + " cards");
        System.out.println("Deck includes:");
        for(Card card : deck)
        {
            System.out.println("Card: " + card.getFace() + " of " +
                    card.getSuit() + " is color " + card.getColor());
        } 
    }

    private void shuffleDeck()
    {
        List<Card> cardList = new ArrayList<Card>(deck);
        Collections.shuffle(cardList);
        deck = new HashSet<Card>(cardList);
    }
}
