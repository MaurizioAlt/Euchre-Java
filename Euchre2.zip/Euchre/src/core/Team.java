/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;

/**
 *
 * @author mauri
 */
public class Team 
{
    private ArrayList<Player> players;
    private int score;
    private int tricks;
    private String teamName; 
    
    public Team()
    {
        players = new ArrayList();
    }
    
    public void outputTeams()
    {
        System.out.println(this.getTeamName() + " includes players:");
    
        for(Player player : this.getPlayers())
        {
            System.out.println("Player: " + player.getName());
        }
    
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getTricks() {
        return tricks;
    }

    public void setTricks(int tricks) {
        this.tricks = tricks;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }
}
