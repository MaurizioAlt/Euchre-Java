/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;

/**
 *
 * @author mauri
 */
public abstract class Player implements IPlayer 
{
    private String name; 
    private int tricks;
    private int bid;
    private int score;
    private ArrayList<Card> hand = new ArrayList();
    
    @Override
    public abstract Card playCard();
    @Override
    public abstract void makeTrump();
    
    public void displayHand()
    {
        //createArray();
        System.out.println("*********************************");
        System.out.println("Player " + name + " hand is ");
        System.out.println("*********************************");
        
        for(Card card : hand)
        {
            System.out.println(card.getFace() + " of " + card.getSuit());
        }
    }
    
    public ArrayList<Card> getHand() {
        return hand;
    }
    
    public void setHand(ArrayList<Card> hand) {
        this.hand = hand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTricks() {
        return tricks;
    }

    public void setTricks(int tricks) {
        this.tricks = tricks;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
